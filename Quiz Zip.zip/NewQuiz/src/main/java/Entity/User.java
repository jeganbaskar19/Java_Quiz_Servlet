package Entity;

public class User {
	
	public int id;
	public String name;
	public String email;
	public String phone;
	public String password;
	
	
	public User() {
		
	}
	public User(String name, String email, String phone, String password) {

		this.name = name;
		this.email = email;
		this.phone = phone;
		this.password = password;
	}
	public User(int id, String name, String email, String phone, String password) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.password = password;
	}
	
	
}
