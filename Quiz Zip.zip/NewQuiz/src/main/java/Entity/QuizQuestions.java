package Entity;


public class QuizQuestions {
	public int id;
	public String question;
	public String A;
	public String B;
	public String C;
	public String D;
	public char correct;
	public String type;
	public QuizQuestions(int id, String question, String a, String b, String c, String d, char correct, String type) {
		this.id = id;
		this.question = question;
		A = a;
		B = b;
		C = c;
		D = d;
		this.correct = correct;
		this.type = type;
	}
	public QuizQuestions(){
		
	}
	
	

}