package Entity;

public class QuizTopics {
	
	public String topic;
	public int count;
	
	public QuizTopics(String topic, int count) {
		this.topic = topic;
		this.count = count;
	}
	

}
