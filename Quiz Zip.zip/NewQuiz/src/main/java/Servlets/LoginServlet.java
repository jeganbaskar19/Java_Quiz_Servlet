package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizTopics;
import Entity.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet  extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		DbConnections db= new DbConnections();
		try {
			User u=db.loginUser(req.getParameter("email"),req.getParameter("password"));
			
			if(u!=null) {
				List<QuizTopics> qt=db.getQuizTopics();
				HttpSession hs= req.getSession();
				hs.setAttribute("user", u);
				hs.setAttribute("quizTopics", qt);
				RequestDispatcher dtp=req.getRequestDispatcher("userdashboard.jsp");
				dtp.forward(req, resp);
			}
			else {
				HttpSession hs= req.getSession();
				hs.setAttribute("msg", "Invaild username & Password");
				resp.sendRedirect("Login.jsp");
			}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
