package Servlets;

import java.io.IOException;
import java.sql.SQLException;

import Entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		DbConnections db=new DbConnections();
		User u=new User(req.getParameter("name"), req.getParameter("email"), req.getParameter("phone"), req.getParameter("password"));
		try {
			String msg=db.register(u);
			HttpSession hs= req.getSession();
			hs.setAttribute("msg", msg);
			resp.sendRedirect("Register.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
