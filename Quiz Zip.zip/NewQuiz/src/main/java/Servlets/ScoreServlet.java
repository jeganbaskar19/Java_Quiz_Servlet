package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizQuestions;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/submit-quiz")
public class ScoreServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		DbConnections db= new DbConnections();
		
		String topic=req.getParameter("topic");
		try {
			List<QuizQuestions> question=db.getQuestionByTopic(topic);
			int total=question.size();
			int score =0;
			for(int i=0;i<total;i++) {
				if(req.getParameter("question"+question.get(i).id)==null) {
					continue;
				}
				char userOption=req.getParameter("question"+question.get(i).id).charAt(0);

				
				if(userOption==question.get(i).correct) {
					score++;
				}
				
			}
			HttpSession hs=req.getSession();
			hs.setAttribute("score", score);
			hs.setAttribute("total", total);
			RequestDispatcher dtp=req.getRequestDispatcher("Score.jsp");
		
			dtp.forward(req, resp);
			
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
