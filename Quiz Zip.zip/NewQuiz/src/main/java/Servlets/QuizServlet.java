package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizQuestions;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/attendquiz")
public class QuizServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String topic=req.getParameter("topic");
		DbConnections db= new DbConnections();
		try {
			List<QuizQuestions> questions=db.getQuestionByTopic(req.getParameter("topic"));
			HttpSession hs= req.getSession();
			hs.setAttribute("questions", questions);
			hs.setAttribute("topic", topic);
			RequestDispatcher dtp=req.getRequestDispatcher("questionform.jsp");
			dtp.forward(req, resp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
