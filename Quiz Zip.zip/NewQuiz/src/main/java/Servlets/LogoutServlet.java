package Servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		HttpSession hs=req.getSession();
		
		hs.removeAttribute("user");
		hs.removeAttribute("quiztopics");
		hs.removeAttribute("score");
		hs.removeAttribute("total");
		hs.removeAttribute("questions");
		hs.removeAttribute("topic");
		resp.sendRedirect("Login.jsp");
		
		
	}

}
