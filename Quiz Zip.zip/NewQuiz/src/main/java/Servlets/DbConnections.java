package Servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.QuizQuestions;
import Entity.QuizTopics;
import Entity.User;

public class DbConnections {
	String url="jdbc:mysql://localhost:3306/JeganQuiz";
	String username="root";
	String password="Jaggu@143";
	   
	   private Connection dbConnect() throws SQLException {
		   return DriverManager.getConnection(url,username,password);
	   }

	public String register(User u) throws SQLException {
		
		if(userAlreadyExist(u.email)) {
			saveUser(u);
			return "Registration Successfull";
		}
			return "Email Id already exist...";
	}

	private void saveUser(User u) throws SQLException {
		Connection con = dbConnect();
		PreparedStatement pst = con.prepareStatement
				("insert into users (Name,Email,Phone,Password) values (?,?,?,?);");
		pst.setString(1,u.name );
		pst.setString(2, u.email);
		pst.setString(3,u.phone );
		pst.setString(4,u.password );
		pst.executeUpdate();
		
	}

	private boolean userAlreadyExist(String email) throws SQLException {
		Connection con= dbConnect();
		PreparedStatement pst=con.prepareStatement("select * from users where Email=?");
		pst.setString(1, email);
		ResultSet rs=pst.executeQuery();
		
		return !(rs.next());
	}
	
	

	public User loginUser(String email, String password) throws SQLException {
		Connection con = dbConnect();
		PreparedStatement pst=con.prepareStatement("select * from users where Email=? AND Password=?");
		pst.setString(1, email);
		pst.setString(2, password);
		ResultSet rs=pst.executeQuery();
		if(rs.next()) {
			User u=new User(rs.getInt("id"),rs.getString("Name"),rs.getString("Email"),rs.getString("Phone"),null);
			return u;
		}
		
		return null;
	}

	public List<QuizTopics> getQuizTopics() throws SQLException {
		Connection con = dbConnect();
		PreparedStatement pst = con.prepareStatement
				("select count(type) as count ,type from Quizes group by type;");
		ResultSet rs= pst.executeQuery();
		List<QuizTopics> topics=new ArrayList<QuizTopics>();
		while(rs.next()) {
			QuizTopics qt= new QuizTopics(rs.getString("type"), rs.getInt("count"));
			topics.add(qt);
		}
		return topics;
	}

	public List<QuizQuestions> getQuestionByTopic(String topic) throws SQLException {
		Connection con =dbConnect();
		PreparedStatement pst=con.prepareStatement("select * from Quizes where type=?");
		pst.setString(1, topic);
		ResultSet rs= pst.executeQuery();
	
		List<QuizQuestions> questions=new ArrayList<QuizQuestions>();
		while(rs.next()) {
			QuizQuestions q=new QuizQuestions
					(rs.getInt("id"), rs.getString("question"), rs.getString("A"), rs.getString("B"),  rs.getString("C"),  rs.getString("D"),  rs.getString("correct").charAt(0), rs.getString("type"));
			questions.add(q);
		}
		
		return questions;
	}
	public void addQuiz(QuizQuestions q) throws SQLException {
		Connection con = dbConnect();
		PreparedStatement pst = con.prepareStatement
				("INSERT INTO Quizes (question, A, B, C, D, correct, type) VALUES(?,?,?,?,?,?,?)");
		pst.setString(1, q.question);
		pst.setString(2, q.A);
		pst.setString(3, q.B);
		pst.setString(4, q.C);
		pst.setString(5, q.D);
		pst.setString(6, String.valueOf(q.correct));
		pst.setString(7, q.type);
		pst.executeUpdate();
		
		
	}
	public QuizQuestions getQuestionById(int qId) throws SQLException {

		

		Connection con =dbConnect();

		PreparedStatement pst = con.prepareStatement

				("Select * from Quizes where id=?");

		pst.setInt(1, qId);

		ResultSet rs= pst.executeQuery();

		QuizQuestions q=new QuizQuestions();

		if(rs.next()) {

			q.id=rs.getInt("id");

			q.question=rs.getString("question");

			q.A=rs.getString("A");

			q.B=rs.getString("B");

			q.C=rs.getString("C");

			q.D=rs.getString("D");

			q.correct=rs.getString("correct").charAt(0);

			q.type=rs.getString("type");

			return q;

		}



		return null;

	}

	public void saveQuiz(QuizQuestions q) throws SQLException {
		Connection con = dbConnect();

		PreparedStatement pst =con.prepareStatement

				("update Quizes set question=?,A=?,B=?,C=?,D=?,correct=?,type=? where id=?;");

		pst.setString(1, q.question);

		pst.setString(2, q.A);

		pst.setString(3, q.B);

		pst.setString(4, q.C);

		pst.setString(5, q.D);

		pst.setString(6, String.valueOf(q.correct));

		pst.setString(7, q.type);

		pst.setInt(8, q.id);

		pst.executeUpdate();

	}

	public void DeleteQuiz(int qId) throws SQLException {
	    Connection con = dbConnect();

	    String deleteQuery = "DELETE FROM Quizes WHERE id = ?";
	    try (PreparedStatement pst = con.prepareStatement(deleteQuery)) {
	        pst.setInt(1, qId);
	        
	        pst.executeUpdate();
	       
	    }

	   
	}

	public void DeleteQuizbytopic(String qId) throws SQLException {
		Connection con = dbConnect();

	    String deleteQuery = "DELETE FROM Quizes WHERE type = ?";
	    try (PreparedStatement pst = con.prepareStatement(deleteQuery)) {
	        pst.setString(1, qId);
	        
	        pst.executeUpdate();
	       
	    }
		
	}


		
	
}

