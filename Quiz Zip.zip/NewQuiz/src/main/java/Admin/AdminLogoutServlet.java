package Admin;



import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/adminlogout")
public class AdminLogoutServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		HttpSession hs=req.getSession();
		
		hs.removeAttribute("username");
		hs.removeAttribute("password");
		hs.removeAttribute("adminQuizTopics");
		hs.removeAttribute("adminTopic");
		hs.removeAttribute("adminQuestion");
		hs.removeAttribute("singleQuestion ");
		resp.sendRedirect("adminLogin.jsp");
		
		
	}

}