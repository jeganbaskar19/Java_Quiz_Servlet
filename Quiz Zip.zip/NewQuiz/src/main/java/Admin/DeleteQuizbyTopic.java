package Admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizTopics;
import Servlets.DbConnections;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/deletequiz")
public class DeleteQuizbyTopic extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String topic=req.getParameter("delete");
		DbConnections db= new DbConnections();
		try {
			db.DeleteQuizbytopic(topic);
			List<QuizTopics> qt;
			qt = db.getQuizTopics();
			HttpSession hs= req.getSession();
			hs.setAttribute("adminQuizTopics", qt);
			resp.sendRedirect("admindashboard.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
