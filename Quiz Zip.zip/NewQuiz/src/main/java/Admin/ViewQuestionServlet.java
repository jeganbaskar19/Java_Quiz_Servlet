package Admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizQuestions;
import Servlets.DbConnections;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/viewallquestion")
public class ViewQuestionServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String topic =req.getParameter("view");
		DbConnections db= new DbConnections();
		
		try {
			List<QuizQuestions> question= db.getQuestionByTopic(topic);
			HttpSession hs=req.getSession();
			hs.setAttribute("adminTopic", topic);
			hs.setAttribute("adminQuestion", question);
			
			RequestDispatcher dtp=req.getRequestDispatcher("viewquestion.jsp");
			dtp.forward(req, resp);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	
	}

}

