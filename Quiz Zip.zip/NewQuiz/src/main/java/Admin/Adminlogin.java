package Admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import Entity.QuizTopics;
import Servlets.DbConnections;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/adminlogin")
public class Adminlogin extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	resp.sendRedirect("adminLogin.jsp");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		DbConnections db= new DbConnections();
		
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		
		if(username.equals("JeganStark")&&password.equals("6647888")) {
			
			List<QuizTopics> qt;
			try {
				qt = db.getQuizTopics();
				
				HttpSession hs= req.getSession();
				hs.setAttribute("adminQuizTopics", qt);
			
				RequestDispatcher dtp=req.getRequestDispatcher("admindashboard.jsp");
				dtp.forward(req, resp);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
			
			
		}else {
			HttpSession hs=req.getSession();
			hs.setAttribute("msg", "Wrong Credentials...");
			resp.sendRedirect("adminlogin.jsp");
		}
		
		
		
	}

}

