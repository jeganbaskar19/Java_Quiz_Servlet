package Admin;



import java.io.IOException;

import java.sql.SQLException;



import Entity.QuizQuestions;

import Servlets.DbConnections;

import jakarta.servlet.RequestDispatcher;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;



@WebServlet("/editquestion")

public class updateQuestionServlet extends HttpServlet {

	

	@Override

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int qId=Integer.valueOf(req.getParameter("edit"));

		

		DbConnections db= new DbConnections();

		

	 try {

		QuizQuestions question=	db .getQuestionById(qId);

		

		if(question!=null) {

			HttpSession hs= req.getSession();

			hs.setAttribute("singleQuestion", question);

			RequestDispatcher dtp = req.getRequestDispatcher("updateQuiz.jsp");

			dtp.forward(req, resp);

		}

		

	} catch (SQLException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

	}

		

		

	}



}
