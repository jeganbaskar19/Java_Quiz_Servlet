package Admin;



import java.io.IOException;

import java.sql.SQLException;

import java.util.List;



import Entity.QuizQuestions;

import Entity.QuizTopics;

import Servlets.DbConnections;

import jakarta.servlet.RequestDispatcher;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;



@WebServlet("/savequiz")
public class SaveQuizServlet extends HttpServlet {

	

	

	@Override

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int id=Integer.valueOf(req.getParameter("update"));

		

		QuizQuestions q=new QuizQuestions();

		q.id=id;

		q.question=req.getParameter("question");

		q.A=req.getParameter("optionA");

		q.B=req.getParameter("optionB");

		q.C=req.getParameter("optionC");

		q.D=req.getParameter("optionD");

		q.correct=req.getParameter("correct").charAt(0);

		q.type=req.getParameter("type");

		

		DbConnections db= new DbConnections();

		try {

			db.saveQuiz(q);

			

			List<QuizTopics> qt;

			qt = db.getQuizTopics();

			HttpSession hs= req.getSession();

			hs.setAttribute("adminQuizTopics", qt);

			

			RequestDispatcher dtp= req.getRequestDispatcher("admindashboard.jsp");

			dtp.forward(req, resp);

			

			

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		

		

		

	}

	



}
